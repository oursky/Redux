//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import Redux

class ___FILEBASENAMEASIDENTIFIER___: StoreType {
    
    static func configureStore() -> ReduxStore {
        
        /*

            let initialState = AppState(
                todoList: TodoListState(list: [TodoListItem]())
            )
            
            let reducers: [String: Reducer] = [
                kAppStateKeyTodoList: todoListReducer,
            ]
            
            return createStore(combineReducers(reducers), initialState: initialState)

        */
        
        return nil
    }
    
}

