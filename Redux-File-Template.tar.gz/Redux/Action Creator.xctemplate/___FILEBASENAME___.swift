//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import Redux

enum ___VARIABLE_ActionType___: ReduxActionType {
    /*
        case Load
        case LoadSuccess(list: [Item])
        case LoadFail
    */
}


struct ___VARIABLE_ActionCreatorsName___ {
    
    /*
    
        static func load() {
            Store.appStore.dispatch(
                action: ReduxAction(payload: TodoListAction.Load)
            )
        }
    
    */
    
}
